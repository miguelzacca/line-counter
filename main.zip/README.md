# Line counter

Simple code line counter with nodejs. By default ignores the list in `.ignore`

## Usage

- `npm start <path> <query>`

## Examples

```bash
npm start ./my-project js,json,html,css # specifying extensions
```

```bash
npm start ./my-project # all files
```
